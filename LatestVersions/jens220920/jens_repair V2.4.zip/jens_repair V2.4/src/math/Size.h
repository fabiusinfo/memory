#ifndef __CSize__
#define __CSize__

class CSize {
	public:
		int cx,cy;
};

#endif
